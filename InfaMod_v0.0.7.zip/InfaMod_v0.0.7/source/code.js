﻿var Infa = {};
(function () {
	Infa.addPlatformA = function () {
		var icon = './mods/InfaMod_v0.0.7/Consoles/img/A.png';
		GDT.addPlatform(
			{
				id: 'InfaCart1',
				name: 'InfaCart',
				company: 'InfaRealm Studios',
				startAmount: 0.15,
				unitsSold: 0.400,
				licencePrize: 10000,
				published: '1/6/3',
				platformRetireDate: '3/6/3',
				developmentCosts: 5000,
				genreWeightings: [0.8, 0.7, 0.8, 1, 0.6, 0.9],
				audienceWeightings: [0.8, 0.9, 1],
				techLevel: 1,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621933BF',
						date: '1/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "A company by the name of InfaRealm Studios has announced a new game console called the InfaCart. They say that it will feature state of the art graphics processors and a whopping 128k of ram! {0}.".format(General.getETADescription('1/1/3', '1/3/2')),
								image: icon
							});
						}
					}
				]
			});
	}

	Infa.addPlatformB = function () {
		var icon = './mods/InfaMod_v0.0.7/Consoles/img/B.png';
		GDT.addPlatform(
			{
				id: 'InfaCart2',
				name: 'InfaHex',
				company: 'InfaRealm Studios',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 10000,
				published: '4/6/3',
				platformRetireDate: '6/6/3',
				developmentCosts: 8000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.9, 0.8],
				techLevel: 3,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BG',
						date: '4/5/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "InfaRealm Studios has announced a sequel to the InfaCart, dubbed the InfaHex! Rumors state that it features new 3D graphics, perfect for new games. An employee from InfaRealm Studios leaked that it contains online connectivity over your telephone line. We will see how well the console performs next month {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	}

	Infa.addPlatformC = function () {
		var icon = './mods/InfaMod_v0.0.7/Consoles/img/C.png';
		GDT.addPlatform(
			{
				id: 'InfaDisk1',
				name: 'InfaDisk',
				company: 'InfaRealm Studios',
				startAmount: 0.6,
				unitsSold: 1,
				licencePrize: 20000,
				published: '7/2/3',
				platformRetireDate: '11/1/3',
				developmentCosts: 10000,
				genreWeightings: [0.9, 0.9, 1, 0.8, 0.8, 0.9],
				audienceWeightings: [0.9, 1, 0.9],
				techLevel: 3,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621733BH',
						date: '7/1/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "InfaRealm Studios has announced their new console today called the InfaDisk. The new console features a fun look to it and has an extensive list of features. It features connectivity to the World Wide Web but unlike its predecessor it can also use this feature for gaming with friends all around the globe!, The console will be made available next month.,    {0}.".format(General.getETADescription('3/1/3', '4/2/1')),
								image: icon
							});
						}
					}
				]
			});
	}
	
	Infa.addPlatformD = function () {
		var icon = './mods/InfaMod_v0.0.7/Consoles/img/D.png';
		GDT.addPlatform(
			{
				id: 'alienware',
				name: 'Alienhair V51',
				company: 'Yell',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 100000,
				published: '25/6/3',
				platformRetireDate: '30/6/3',
				developmentCosts: 30000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.9, 0.8],
				techLevel: 6,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BI',
						date: '24/5/2',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Computer pioneer Yell has just announced that they are creating a new division called Alienhair. Alienhair will make computers for the purpose of gaming. These computers will start rolling out mid next year. {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	}
	
	Infa.addPlatformE = function () {
		var icon = './mods/InfaMod_v0.0.7/Consoles/img/E.png';
		GDT.addPlatform(
			{
				id: 'GR5',
				name: 'GrPhone 5',
				company: 'Grapple',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 6000,
				published: '28/6/3',
				platformRetireDate: '31/6/3',
				developmentCosts: 1000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.9, 0.8],
				techLevel: 5,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BJ',
						date: '28/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, Grapple is back in action showing off their new GrPhone 5 for the first time. The new phone features a new processor and and stylish new metal and glass look. {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	}
	
	Infa.addPlatformF = function () {
		var icon = './mods/InfaMod_v0.0.7/Consoles/img/F.png';
		GDT.addPlatform(
			{
				id: 'GRS',
				name: 'GrPhone S',
				company: 'Grapple',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 6000,
				published: '26/6/3',
				platformRetireDate: '29/6/3',
				developmentCosts: 1000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.9, 0.8],
				techLevel: 5,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BK',
						date: '26/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, Grapple introduced the new GrPhone S. The new phone features a new processor but looks very similar. Grapple also stated that the cellular reception would be improved. {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	}
	
	Infa.addPlatformG = function () {
		var icon = './mods/InfaMod_v0.0.7/Consoles/img/G.png';
		GDT.addPlatform(
			{
				id: 'star',
				name: 'InfaStar',
				company: 'InfaRealm Studios',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 10000,
				published: '12/6/3',
				platformRetireDate: '16/6/3',
				developmentCosts: 5000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.9, 0.8],
				techLevel: 4,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BL',
						date: '12/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, InfaRealm Studios has announced their new platform called the InfaStar. It features a whole new controller layout, causing a stir in their current console lineup. The new console looks awfully similar to the Panoramic 2DO. {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	}
	
	Infa.addPlatformI = function () {
		var icon = './mods/InfaMod_v0.0.7/Consoles/img/I.png';
		GDT.addPlatform(
			{
				id: 'GO',
				name: 'InfaGO!',
				company: 'InfaRealm Studios',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 5000,
				published: '18/6/3',
				platformRetireDate: '22/6/3',
				developmentCosts: 1000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.9, 0.8],
				techLevel: 4,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BM',
						date: '18/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, InfaRealm Studios has announced their very first portable platform called the InfaGO!. It features the well known DogBone controller layout used in every one of their consoles up to the InfaStar. Although it is their most current platform, it still uses the older cartridge method for games. {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	}
	
	Infa.addPlatformH = function () {
		var icon = './mods/InfaMod_v0.0.7/Consoles/img/H.png';
		GDT.addPlatform(
			{
				id: 'Vilips',
				name: 'Vilips CG-i',
				company: 'Vilips',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 12000,
				published: '9/6/3',
				platformRetireDate: '13/6/3',
				developmentCosts: 3000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.9, 0.8],
				techLevel: 4,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BN',
						date: '9/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, Vilips has announced their new platform called the Vilips CG-i. A spokesperson says that it features stunning cinematic graphics like a movie! But will it be too much like a movie?{0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	};
	
	Infa.addResearch = function () {
		GDT.addResearchItem(
		{
			id: "Main", 
			name: "Main Menu Customization".localize(),
			v: 4,
			canResearch: function (company) {
				return LevelCalculator.getMissionLevel('Level Design') > 4
			},
			category: "Level Design",
			categoryDisplayName: "Level Design".localize()
		});
	};
})();