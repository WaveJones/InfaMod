###Official Game Dev Tycoon Modding API mod

This is the official Modding API mod that ships with Game Dev Tycoon version 1.4.5+

It is a set of [add-on methods and documentation](https://github.com/greenheartgames/gdt-modAPI/wiki "Wiki") to make the implementation of other mods easier.

Pull requests are more than welcome.

##Wiki

Please check the official documentation at:

[https://github.com/greenheartgames/gdt-modAPI/wiki](https://github.com/greenheartgames/gdt-modAPI/wiki)