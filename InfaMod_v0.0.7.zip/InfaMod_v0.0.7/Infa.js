﻿(function () {
	var ready = function () {
		Infa.addPlatformA();
		Infa.addPlatformB();
		Infa.addPlatformC();
		Infa.addPlatformD();
		Infa.addPlatformE();
		Infa.addPlatformF();
		Infa.addPlatformG();
		Infa.addPlatformH();
		Infa.addPlatformI();
	};

	var error = function () {
	};

	GDT.loadJs(['mods/InfaMod_v0.0.7/source/code.js'], ready, error);
})();