﻿var Infa = {};
(function () {
	Infa.addPlatformA = function () {
		var icon = './mods/InfaMod_v1.0.0/Consoles/img/A.png';
		GDT.addPlatform(
			{
				id: 'InfaCart1',
				name: 'InfaCart',
				company: 'InfaRealm Studios',
				startAmount: 0.15,
				unitsSold: 0.400,
				licencePrize: 10000,
				published: '1/6/3',
				platformRetireDate: '3/6/3',
				developmentCosts: 5000,
				genreWeightings: [0.8, 0.7, 0.8, 1, 0.6, 0.9],
				audienceWeightings: [0.8, 0.9, 1],
				techLevel: 1,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621933BA',
						date: '1/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "A company by the name of InfaRealm Studios has announced a new game console called the InfaCart. They say that it will feature state of the art graphics processors and a whopping 128k of ram! {0}.".format(General.getETADescription('1/1/3', '1/3/2')),
								image: icon
							});
						}
					}
				]
			});
	}

	Infa.addPlatformB = function () {
		var icon = './mods/InfaMod_v1.0.0/Consoles/img/B.png';
		GDT.addPlatform(
			{
				id: 'InfaCart2',
				name: 'InfaHex',
				company: 'InfaRealm Studios',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 10000,
				published: '4/6/3',
				platformRetireDate: '6/6/3',
				developmentCosts: 8000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.9, 0.8],
				techLevel: 3,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BB',
						date: '4/5/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "InfaRealm Studios has announced a sequel to the InfaCart, dubbed the InfaHex! Rumors state that it features new 3D graphics, perfect for new games. An employee from InfaRealm Studios leaked that it contains online connectivity over your telephone line. We will see how well the console performs next month {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	}

	Infa.addPlatformC = function () {
		var icon = './mods/InfaMod_v1.0.0/Consoles/img/C.png';
		GDT.addPlatform(
			{
				id: 'InfaDisk1',
				name: 'InfaDisk',
				company: 'InfaRealm Studios',
				startAmount: 0.6,
				unitsSold: 1,
				licencePrize: 20000,
				published: '7/2/3',
				platformRetireDate: '11/1/3',
				developmentCosts: 10000,
				genreWeightings: [0.9, 0.9, 1, 0.8, 0.8, 0.9],
				audienceWeightings: [0.9, 1, 0.9],
				techLevel: 3,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621733BC',
						date: '7/1/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "InfaRealm Studios has announced their new console today called the InfaDisk. The new console features a fun look to it and has an extensive list of features. It features connectivity to the World Wide Web but unlike its predecessor it can also use this feature for gaming with friends all around the globe!, The console will be made available next month.,    {0}.".format(General.getETADescription('3/1/3', '4/2/1')),
								image: icon
							});
						}
					}
				]
			});
	}
	
	Infa.addPlatformD = function () {
		var icon = './mods/InfaMod_v1.0.0/Consoles/img/D.png';
		GDT.addPlatform(
			{
				id: 'alienware',
				name: 'Alienhair V51',
				company: 'Yell',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 100000,
				published: '25/6/3',
				platformRetireDate: '30/6/3',
				developmentCosts: 30000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.9, 0.8],
				techLevel: 6,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BD',
						date: '24/5/2',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Computer pioneer Yell has just announced that they are creating a new division called Alienhair. Alienhair will make computers for the purpose of gaming. These computers will start rolling out mid next year. {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	}
	
	Infa.addPlatformE = function () {
		var icon = './mods/InfaMod_v1.0.0/Consoles/img/E.png';
		GDT.addPlatform(
			{
				id: 'GR5',
				name: 'GrPhone 5',
				company: 'Grapple',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 6000,
				published: '28/6/3',
				platformRetireDate: '31/6/3',
				developmentCosts: 1000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.9, 0.8],
				techLevel: 5,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BE',
						date: '28/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, Grapple is back in action showing off their new GrPhone 5 for the first time. The new phone features a new processor and and stylish new metal and glass look. {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	}
	
	Infa.addPlatformF = function () {
		var icon = './mods/InfaMod_v1.0.0/Consoles/img/F.png';
		GDT.addPlatform(
			{
				id: 'GRS',
				name: 'GrPhone S',
				company: 'Grapple',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 6000,
				published: '26/6/3',
				platformRetireDate: '29/6/3',
				developmentCosts: 1000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.9, 0.8],
				techLevel: 5,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BF',
						date: '26/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, Grapple introduced the new GrPhone S. The new phone features a new processor but looks very similar. Grapple also stated that the cellular reception would be improved. {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	}
	
	Infa.addPlatformG = function () {
		var icon = './mods/InfaMod_v1.0.0/Consoles/img/G.png';
		GDT.addPlatform(
			{
				id: 'star',
				name: 'InfaStar',
				company: 'InfaRealm Studios',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 10000,
				published: '12/6/3',
				platformRetireDate: '16/6/3',
				developmentCosts: 5000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.9, 0.8],
				techLevel: 4,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BG',
						date: '12/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, InfaRealm Studios has announced their new platform called the InfaStar. It features a whole new controller layout, causing a stir in their current console lineup. The new console looks awfully similar to the Panoramic 2DO. {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	}
	
	Infa.addPlatformI = function () {
		var icon = './mods/InfaMod_v1.0.0/Consoles/img/I.png';
		GDT.addPlatform(
			{
				id: 'GO',
				name: 'InfaGO!',
				company: 'InfaRealm Studios',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 5000,
				published: '18/6/3',
				platformRetireDate: '22/6/3',
				developmentCosts: 1000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.9, 0.8],
				techLevel: 4,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BH',
						date: '18/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, InfaRealm Studios has announced their very first portable platform called the InfaGO!. It features the well known DogBone controller layout used in every one of their consoles up to the InfaStar. Although it is their most current platform, it still uses the older cartridge method for games. {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	}
	
	Infa.addPlatformH = function () {
		var icon = './mods/InfaMod_v1.0.0/Consoles/img/H.png';
		GDT.addPlatform(
			{
				id: 'Vilips',
				name: 'Vilips CG-i',
				company: 'Vilips',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 12000,
				published: '9/6/3',
				platformRetireDate: '13/6/3',
				developmentCosts: 3000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.9, 0.8],
				techLevel: 4,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BI',
						date: '9/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, Vilips has announced their new platform called the Vilips CG-i. A spokesperson says that it features stunning cinematic graphics like a movie! But will it be too much like a movie?{0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	};
	
	Infa.addResearch = function () {
		GDT.addResearchItem(
		{
			id: "Main", 
			name: "Main Menu Customization".localize(),
			v: 4,
			canResearch: function (company) {
				return LevelCalculator.getMissionLevel('Level Design') > 4
			},
			category: "Level Design",
			categoryDisplayName: "Level Design".localize()
		});
	};
	
	Infa.addResearch = function () {
		GDT.addResearchItem(
		{
			id: "DigiSono", 
			name: "Digital Sound".localize(),
			v: 8,
			canResearch: function (company) {
				return LevelCalculator.getMissionLevel('Sound') > 7
			},
			category: "Sound",
			categoryDisplayName: "Sound".localize()
		});
	};
	
	Infa.addResearch = function () {
		GDT.addResearchItem(
		{
			id: "ConsoleComp", 
			name: "Console Compatibility".localize(),
			v: 2,
			canResearch: function (company) {
				return LevelCalculator.getMissionLevel('Engine') > 3
			},
			category: "Engine",
			categoryDisplayName: "Engine".localize()
		});
	};
	
	Infa.addPlatformJ = function () {
		var icon = './mods/InfaMod_v1.0.0/Consoles/img/J.png';
		GDT.addPlatform(
			{
				id: 'Nitro32',
				name: 'NitroGrafx32',
				company: 'Neck',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 50000,
				published: '2/6/3',
				platformRetireDate: '13/6/3',
				developmentCosts: 10000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.9, 0.8],
				techLevel: 4,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BJ',
						date: '2/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, NECK has announced their first console called the NitroGrafx32. An employee from the company says that it features new, radical 16 bit action! We cant wait to see teh new console!{0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	};
	
	Infa.addPlatformK = function () {
		var icon = './mods/InfaMod_v1.0.0/Consoles/img/K.png';
		GDT.addPlatform(
			{
				id: 'Sick',
				name: 'GameSick',
				company: 'PlayJan',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 20000,
				published: '29/6/3',
				platformRetireDate: '32/6/3',
				developmentCosts: 10000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.9, 0.8],
				techLevel: 5,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BK',
						date: '29/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, the new console called the GameSick was released. The console was a project started on the popular start up website, Dropkickstarter. It runs on the popular mobile platform called Yandroid. We will see how the platform performs{0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	};
	
	Infa.addPlatformL = function () {
		var icon = './mods/InfaMod_v1.0.0/Consoles/img/L.png';
		GDT.addPlatform(
			{
				id: 'Graptop',
				name: 'Grapbook Air',
				company: 'Grapple',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 50000,
				published: '29/6/3',
				platformRetireDate: '32/6/3',
				developmentCosts: 20000,
				genreWeightings: [0.9, 1, 0.9, 0.7, 1, 0.8],
				audienceWeightings: [1, 0.9, 1],
				techLevel: 6,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BL',
						date: '29/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, Grapple has released their new laptop called the GrapBook Air. The laptop is super thin, hence the name air. The laptop runs on the same operating system their other computers, GrapOSX {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	};
	
	Infa.addPlatformM = function () {
		var icon = './mods/InfaMod_v1.0.0/Consoles/img/M.png';
		GDT.addPlatform(
			{
				id: 'Guy',
				name: 'Virtual Guy',
				company: 'Ninvento',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 15000,
				published: '12/6/3',
				platformRetireDate: '13/6/3',
				developmentCosts: 10000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.7, 0.5],
				techLevel: 4,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BM',
						date: '12/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, the new console from Ninvento was released. First players recall feeling very nauseous and experienced headaches after playing with the console for extended amounts of time. We don't think this console will last very long. {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	};
	
	Infa.addPlatformN = function () {
		var icon = './mods/InfaMod_v1.0.0/Consoles/img/N.png';
		GDT.addPlatform(
			{
				id: 'pod',
				name: 'GrPod',
				company: 'Grapple',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 0,
				published: '12/6/3',
				platformRetireDate: '13/6/3',
				developmentCosts: 10000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [1, 0.7, 0.7],
				techLevel: 2,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BN',
						date: '12/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, hackers have found a way around the security in the recently released GrPod. This allows people to develop games onto the GrPod. {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	};
	
	Infa.addPlatformO = function () {
		var icon = './mods/InfaMod_v0.0.8/Consoles/img/O.png';
		GDT.addPlatform(
			{
				id: 'Tab',
				name: 'InfaTab',
				company: 'InfaRealm Studios',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 40000,
				published: '30/6/3',
				platformRetireDate: '34/6/3',
				developmentCosts: 10000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [0.5, 1, 1],
				techLevel: 5,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BO',
						date: '34/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, the new InfaTab by InfaRealm Studios was released. It looks similar to the GrPad, but its specs seem to be higher than Grapple's tablet.  {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	};
	
	Infa.addPlatformP = function () {
		var icon = './mods/InfaMod_v0.0.8/Consoles/img/P.png';
		GDT.addPlatform(
			{
				id: 'Zub',
				name: 'ZuberSystem',
				company: 'Zuber',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 60000,
				published: '25/6/3',
				platformRetireDate: '28/6/3',
				developmentCosts: 10000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [0.5, 1, 1],
				techLevel: 5,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BP',
						date: '25/4/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, newcomer Zuber has announced their game console, the ZuberSystem. It features great graphic quality.  {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	};
	
	Infa.addPlatformQ = function () {
		var icon = './mods/InfaMod_v0.0.8/Consoles/img/Q.png';
		GDT.addPlatform(
			{
				id: 'Erikchild',
				name: 'Ericchild Zperia Play',
				company: 'Vonny',
				startAmount: 0.2,
				unitsSold: 0.9,
				licencePrize: 50000,
				published: '25/3/3',
				platformRetireDate: '27/6/3',
				developmentCosts: 15000,
				genreWeightings: [0.9, 1, 0.9, 0.6, 1, 0.8],
				audienceWeightings: [0.5, 1, 1],
				techLevel: 5,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621833BQ',
						date: '25/1/3',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "Today, Vonny has announced their platform that is said to dominate the mobile phone market. It looks just like the PPS GO, but features multiplayer over 3G.  {0}.".format(General.getETADescription('1/7/3', '2/4/1')),
								image: icon
							});
						}
					}
				]
			});
	};
})();