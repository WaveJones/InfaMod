﻿(function () {
	var ready = function () {
		Infa.addPlatformA();
		Infa.addPlatformB();
		Infa.addPlatformC();
		Infa.addPlatformD();
		Infa.addPlatformE();
		Infa.addPlatformF();
		Infa.addPlatformG();
		Infa.addPlatformH();
		Infa.addPlatformI();
		Infa.addPlatformJ();
		Infa.addPlatformK();
		Infa.addPlatformL();
		Infa.addPlatformM();
		Infa.addPlatformN();
		Infa.addPlatformO();
		Infa.addPlatformP();
		Infa.addPlatformQ();
	};

	var error = function () {
	};

	GDT.loadJs(['mods/InfaMod_v1.0.0/source/code.js'], ready, error);
})();